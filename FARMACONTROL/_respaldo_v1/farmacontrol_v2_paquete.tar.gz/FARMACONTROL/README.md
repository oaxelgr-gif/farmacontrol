# FarmaControl 2.0

Sistema de punto de venta, inventario, caja y reportes para **MEDICALIFE**.
Versión reestructurada: backend modular (un blueprint por apartado) e interfaz
nueva estilo *Liquid Glass* con modo claro/oscuro.

## Cómo ejecutar

```bash
pip install -r requirements.txt
cp .env.example .env        # opcional: ajusta BD y clave secreta
python app.py               # http://localhost:5010
```

Si no creas `.env`, se usan los mismos valores de la versión anterior
(BD `medicalife`, usuario `root`, puerto 5010). No requiere cambios en la base de datos.

## Estructura

```
app.py                      → punto de entrada (python app.py)
config.py                   → configuración (lee .env)
farmacontrol/
├── __init__.py             → create_app(): registra blueprints, errores, contexto
├── db.py                   → conexión por petición + fetch_all/fetch_one/execute/transaction
├── models.py               → Usuario y roles (1 Admin, 2 Farmacéutico)
├── navigation.py           → menú lateral por rol (editar aquí para cambiar el menú)
├── blueprints/
│   ├── auth/               → /login, /logout, /
│   ├── dashboard/          → /inicio (admin), /inicio_farmacia
│   ├── inventario/         → /inventario, /producto/...
│   ├── usuarios/           → /usuarios, /usuario/...
│   ├── caja/               → /corte_caja, /abrir_caja, /cerrar_caja
│   ├── cortes/             → historial, detalle, impresión, auditoría y CSV de cortes
│   ├── ventas/             → punto de venta, tickets, detalle y reimpresión
│   ├── api/                → /api/... (búsqueda, clientes, cobro)
│   ├── reportes/           → los 8 reportes + panel
│   ├── servicios/          → servicios y consultas
│   └── sistema/            → /test_db
├── services/               → lógica de negocio (ventas, cortes, caducidad, catálogos)
└── utils/                  → decoradores, contraseñas, fechas y filtros de plantilla
templates/                  → una carpeta por apartado + layouts/ y partials/
static/css/glass.css        → sistema de diseño (tokens, vidrio, componentes)
static/js/app.js, pos.js    → utilidades de UI y punto de venta
```

Todas las URLs anteriores se conservan. En plantillas, los `url_for` ahora llevan
el prefijo del blueprint, p. ej. `url_for('inventario.listar_productos')`.

## Mejoras principales

**Backend**
- `app.py` de 2,750 líneas dividido en 11 blueprints + capa de servicios.
- Ventas en una sola transacción real (antes `autocommit` impedía el rollback).
- Precios, total y cambio se calculan en el servidor; ya no se confía en el navegador.
- Servicios/consultas se guardan con `producto_id = NULL` (antes se registraban como si fueran un producto con el mismo id, alterando reportes).
- Bloqueo de stock (`FOR UPDATE`) y validación de caducidad al cobrar.
- Contraseñas con hash; las cuentas existentes se migran solas al iniciar sesión.
- `/gestion/guardar` ahora exige rol de administrador; tabla en lista blanca.
- Métodos de pago clasificados por nombre (en la BD el id 3 es *Débito*, no *Transferencia*).
- Reporte financiero: corregido el ingreso que se multiplicaba por cada renglón de la venta.
- Corregidas plantillas que fallaban: reimpresión de cortes y de tickets, tickets de corte (`now()`, campos faltantes, `ventas_otros`).
- Folios con milisegundos para evitar duplicados; páginas de error 404/500; cabeceras de seguridad.

**Interfaz**
- Diseño *Liquid Glass*: superficies translúcidas con desenfoque, reflejos y fondo animado.
- Modo oscuro (botón de luna) que se recuerda por navegador.
- Barra lateral única por rol; en celular se vuelve barra inferior.
- Punto de venta: búsqueda con filtro en vivo, cantidades editables, botones de billetes rápidos y cálculo de cambio, métodos de pago tomados de la BD, aviso de antibióticos.
- Panel con gráfica semanal, cobros por método y más vendidos; mensajes como notificaciones flotantes; confirmaciones con ventana propia.

## Respaldo

La versión anterior quedó en `_respaldo_v1/` (app.py, models.py, plantillas y CSS originales).
