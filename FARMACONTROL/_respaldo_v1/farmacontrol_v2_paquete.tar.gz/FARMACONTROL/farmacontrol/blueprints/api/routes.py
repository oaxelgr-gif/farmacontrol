"""API JSON del punto de venta (búsqueda, clientes, catálogos y cobro)."""
from flask import Blueprint, jsonify, request
from flask_login import current_user, login_required

from ...db import execute, fetch_all, fetch_one, to_float
from ...models import ROL_ADMIN
from ...services import caducidad
from ...services import ventas as svc_ventas

bp = Blueprint("api", __name__, url_prefix="/api")


def _producto_json(p):
    return {
        "id": p["id"],
        "nombre": p["nombre"],
        "precio": to_float(p["precio_publico"]),
        "stock": int(p["stock_actual"] or 0),
        "stock_actual": int(p["stock_actual"] or 0),
        "antibiotico": bool(p["antibiotico"]),
        "codigo_barras": p.get("codigo_barras"),
        "estado_caducidad": p["estado_caducidad"],
        "tipo": "producto",
    }


@bp.route("/buscar_producto")
@login_required
def buscar_producto():
    query = (request.args.get("query") or "").strip()
    if not query:
        return jsonify(success=False, message="Consulta vacía")

    mostrar_todos = request.args.get("mostrar_caducados", "false").lower() == "true" \
        and current_user.rol == ROL_ADMIN
    filtro = "" if mostrar_todos else caducidad.condicion_vendible()
    estado = caducidad.estado_sql()

    # 1. Coincidencia exacta por código de barras (lector)
    exacto = fetch_one(
        f"""SELECT id, nombre, codigo_barras, precio_publico, stock_actual, antibiotico,
                   fecha_caducidad, {estado} AS estado_caducidad
            FROM productos
            WHERE codigo_barras = %s AND status = 1""",
        (query,),
    )
    if exacto:
        if int(exacto["stock_actual"] or 0) <= 0:
            return jsonify(success=False, message=f"«{exacto['nombre']}» no tiene existencias.")
        if not mostrar_todos and not caducidad.es_vendible(exacto["estado_caducidad"]):
            return jsonify(success=False,
                           message=f"Producto {exacto['estado_caducidad'].lower()}. No se puede vender.",
                           estado=exacto["estado_caducidad"])
        return jsonify(success=True, tipo="exacto", data=_producto_json(exacto))

    # 2. Búsqueda por nombre / código parcial
    resultados = fetch_all(
        f"""SELECT id, nombre, codigo_barras, precio_publico, stock_actual, antibiotico,
                   fecha_caducidad, {estado} AS estado_caducidad
            FROM productos
            WHERE (nombre LIKE %s OR codigo_barras LIKE %s)
              AND status = 1 AND stock_actual > 0 {filtro}
            ORDER BY nombre LIMIT 15""",
        (f"%{query}%", f"%{query}%"),
    )
    if resultados:
        return jsonify(success=True, tipo="lista", data=[_producto_json(r) for r in resultados])

    bloqueados = fetch_one(
        "SELECT COUNT(*) AS n FROM productos WHERE nombre LIKE %s AND status = 1 AND stock_actual > 0",
        (f"%{query}%",),
    )
    if bloqueados and bloqueados["n"]:
        return jsonify(success=False,
                       message="Los productos encontrados están caducados o próximos a caducar.",
                       encontrados_caducados=bloqueados["n"])
    return jsonify(success=False, message="No encontrado o sin stock")


@bp.route("/clientes", methods=["GET"])
@login_required
def api_get_clientes():
    q = (request.args.get("q") or "").strip()
    sql = "SELECT id, nombre, rfc_nit, telefono, email FROM clientes WHERE status = 1"
    params = []
    if q:
        sql += " AND (nombre LIKE %s OR rfc_nit LIKE %s OR telefono LIKE %s)"
        params += [f"%{q}%"] * 3
    sql += " ORDER BY nombre LIMIT 25"
    return jsonify(fetch_all(sql, params))


@bp.route("/clientes/nuevo", methods=["POST"])
@login_required
def api_nuevo_cliente():
    f = request.get_json(silent=True) or request.form
    nombre = (f.get("nombre") or "").strip()
    if not nombre:
        return jsonify(success=False, message="Nombre requerido")
    try:
        nuevo_id = execute(
            """INSERT INTO clientes (nombre, rfc_nit, direccion, telefono, email, status)
               VALUES (%s, %s, %s, %s, %s, 1)""",
            (nombre, (f.get("rfc_nit") or "").strip() or None, (f.get("direccion") or "").strip() or None,
             (f.get("telefono") or "").strip() or None, (f.get("email") or "").strip() or None),
        )
    except Exception as exc:
        return jsonify(success=False, message=f"No se pudo guardar: {exc}")
    return jsonify(success=True, id=nuevo_id, nombre=nombre)


@bp.route("/items/<tipo>")
@login_required
def api_get_items(tipo):
    if tipo == "productos":
        mostrar_todos = request.args.get("mostrar_caducados", "false").lower() == "true" \
            and current_user.rol == ROL_ADMIN
        filtro = "" if mostrar_todos else caducidad.condicion_vendible()
        productos = fetch_all(
            f"""SELECT id, nombre, codigo_barras, precio_publico, stock_actual, antibiotico,
                       fecha_caducidad, {caducidad.estado_sql()} AS estado_caducidad
                FROM productos
                WHERE status = 1 AND stock_actual > 0 {filtro}
                ORDER BY nombre""")
        return jsonify([_producto_json(p) for p in productos])

    tablas = {"procedimientos": ("servicios", "servicio"), "consultas": ("consultas", "consulta")}
    if tipo not in tablas:
        return jsonify([])
    tabla, tipo_item = tablas[tipo]
    filas = fetch_all(f"SELECT id, nombre, precio FROM {tabla} WHERE status = 1 ORDER BY nombre")
    return jsonify([{"id": r["id"], "nombre": r["nombre"], "precio": to_float(r["precio"]),
                     "tipo": tipo_item} for r in filas])


@bp.route("/validar_producto_caducidad/<int:producto_id>")
@login_required
def validar_producto_caducidad(producto_id):
    p = fetch_one(
        f"""SELECT nombre, fecha_caducidad, {caducidad.estado_sql()} AS estado_caducidad,
                   DATEDIFF(fecha_caducidad, CURDATE()) AS dias_restantes
            FROM productos WHERE id = %s AND status = 1""",
        (producto_id,),
    )
    if not p:
        return jsonify(success=False, message="Producto no encontrado")
    return jsonify(success=True, producto=p["nombre"], estado_caducidad=p["estado_caducidad"],
                   dias_restantes=p["dias_restantes"], es_valido=caducidad.es_vendible(p["estado_caducidad"]))


@bp.route("/procesar_venta", methods=["POST"])
@login_required
def api_procesar_venta():
    data = request.get_json(silent=True) or {}
    try:
        res = svc_ventas.procesar_venta(data, current_user.id)
    except svc_ventas.VentaError as exc:
        return jsonify(success=False, message=str(exc))
    except Exception as exc:
        return jsonify(success=False, message=f"Error en servidor: {exc}"), 500
    return jsonify(success=True, venta_id=res["venta_id"], folio=res["folio"],
                   total_vendido=res["total"], monto_entrega=res["total"],
                   pago=res["pago"], cambio=res["cambio"], metodo=res["metodo"])
