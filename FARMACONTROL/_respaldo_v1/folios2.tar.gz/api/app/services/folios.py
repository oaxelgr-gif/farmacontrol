"""
Folios seriados y revueltos.

Cada folio codifica  fecha (DDMMAA) + id de usuario + operación del día,
pero los dígitos se mezclan con un cifrado reversible (red Feistel con clave),
así que dos ventas seguidas producen folios que no se parecen:

    13/10/26 · usuario 2 · op 1   →  08015-16581-17118
    13/10/26 · usuario 2 · op 2   →  78389-77065-04653

- Es único: el cifrado es biyectivo (no hay dos ventas con el mismo folio).
- Es verificable: el último dígito es un dígito de control (Luhn).
- Es decodificable: con la clave (FOLIO_CLAVE) se recupera fecha, usuario y operación.

IMPORTANTE: el servicio web y la API deben usar la misma FOLIO_CLAVE.
Este archivo es idéntico en farmacontrol/services/ y api/app/services/.
"""
import hashlib
import hmac
import os
from datetime import datetime

INTENTOS = 5
_RONDAS = 8
_MITAD = 10 ** 7          # dos mitades de 7 dígitos → dominio de 14 dígitos
_CLAVE = os.getenv("FOLIO_CLAVE", "farmacontrol-folios-2026").encode()


# ------------------------------------------------------------------ cifrado
def _f(ronda, valor):
    h = hmac.new(_CLAVE, f"{ronda}:{valor}".encode(), hashlib.sha256).hexdigest()
    return int(h, 16) % _MITAD


def _cifrar(n):
    izq, der = divmod(n, _MITAD)
    for r in range(_RONDAS):
        izq, der = der, (izq + _f(r, der)) % _MITAD
    return izq * _MITAD + der


def _descifrar(n):
    izq, der = divmod(n, _MITAD)
    for r in reversed(range(_RONDAS)):
        izq, der = (der - _f(r, izq)) % _MITAD, izq
    return izq * _MITAD + der


def _luhn(digitos):
    total = 0
    for i, d in enumerate(reversed(digitos)):
        n = int(d)
        if i % 2 == 0:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return str((10 - total % 10) % 10)


# ------------------------------------------------------------------ API pública
def codificar(fecha, usuario_id, operacion):
    """fecha + usuario + operación → 'XXXXX-XXXXX-XXXXX'."""
    plano = int(f"{fecha:%d%m%y}{int(usuario_id) % 1000:03d}{int(operacion) % 10000:04d}")
    cifrado = f"{_cifrar(plano):014d}"
    d = cifrado + _luhn(cifrado)
    return f"{d[:5]}-{d[5:10]}-{d[10:]}"


def decodificar(folio):
    """Devuelve {'fecha', 'usuario_id', 'operacion'} o None si no es un folio de este formato."""
    d = str(folio or "").replace("-", "")
    if len(d) != 15 or not d.isdigit() or _luhn(d[:14]) != d[14]:
        return None
    plano = f"{_descifrar(int(d[:14])):013d}"
    try:
        fecha = datetime.strptime(plano[:6], "%d%m%y").date()
    except ValueError:
        return None
    return {"fecha": fecha, "usuario_id": int(plano[6:9]), "operacion": int(plano[9:13])}


def siguiente(consultar, usuario_id, intento=0, fecha=None):
    """
    Siguiente folio del usuario para hoy.
    `consultar(sql, params)` devuelve una fila (dict). Se ejecuta dentro de la
    transacción de la venta; `intento` suma 1 por cada choque al insertar.
    """
    fecha = fecha or datetime.now()
    fila = consultar(
        """SELECT COUNT(*) AS n FROM ventas
           WHERE usuario_id = %s AND fecha >= CURDATE() AND fecha < CURDATE() + INTERVAL 1 DAY
           FOR UPDATE""",
        (usuario_id,),
    )
    hechas = int((fila or {}).get("n") or 0)
    return codificar(fecha, usuario_id, hechas + 1 + intento)


def es_duplicado(exc):
    texto = str(exc)
    return "Duplicate" in texto or "UNIQUE" in texto or "1062" in texto
