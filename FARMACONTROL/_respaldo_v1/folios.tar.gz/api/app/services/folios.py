"""
Folios seriados de venta.

Formato:  DDMMAA-UUU-NNNN
          │      │   └─ número de operación del usuario en ese día (0001, 0002…)
          │      └───── id del usuario (3 dígitos)
          └──────────── día, mes y año
Ejemplo:  131026-002-0001  → 13/oct/2026, usuario 2, primera venta del día.

El consecutivo se reinicia cada día por usuario. Se calcula dentro de la
transacción de la venta con bloqueo (FOR UPDATE) y, si dos cajas chocaran,
se reintenta con el siguiente número.
"""
from datetime import datetime

INTENTOS = 5


def prefijo(usuario_id, fecha=None):
    fecha = fecha or datetime.now()
    return f"{fecha:%d%m%y}-{int(usuario_id):03d}-"


def siguiente(consultar, usuario_id, fecha=None):
    """`consultar(sql, params)` debe devolver una fila (dict) o None."""
    pre = prefijo(usuario_id, fecha)
    fila = consultar(
        "SELECT folio FROM ventas WHERE folio LIKE %s ORDER BY folio DESC LIMIT 1 FOR UPDATE",
        (pre + "%",),
    )
    numero = 1
    if fila and fila.get("folio"):
        try:
            numero = int(str(fila["folio"])[len(pre):]) + 1
        except ValueError:
            numero = 1
    return f"{pre}{numero:04d}"


def es_duplicado(exc):
    texto = str(exc)
    return "Duplicate" in texto or "UNIQUE" in texto or "1062" in texto
